
import React, { useState, useEffect } from 'react';
import { User, Contact } from './types';
import Login from './components/Login';
import Sidebar from './components/Sidebar';
import ChatWindow from './components/ChatWindow';
import ProfileDrawer from './components/ProfileDrawer';
import ContactInfoDrawer from './components/ContactInfoDrawer';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [typingMap, setTypingMap] = useState<Record<string, boolean>>({});
  
  // Drawer states
  const [showMyProfile, setShowMyProfile] = useState(false);
  const [showContactInfo, setShowContactInfo] = useState(false);

  useEffect(() => {
    const lastUser = localStorage.getItem('last_user');
    if (lastUser) {
      setCurrentUser(JSON.parse(lastUser));
    }
  }, []);

  useEffect(() => {
    if (currentUser) {
      const stored = localStorage.getItem(`contacts_${currentUser.id}`);
      if (stored) {
        setContacts(JSON.parse(stored));
      } else {
        const defaults: Contact[] = [
          { id: 'gemini-pro', name: 'Gemini AI', avatar: 'https://picsum.photos/seed/ai/200', bio: 'The latest Gemini 3 model for reasoning.', status: 'online', isAI: true },
          { id: 'support', name: 'Hafeez Support', avatar: 'https://picsum.photos/seed/supp/200', bio: 'Official support for Hafeez Chat.', status: 'online', isAI: true }
        ];
        setContacts(defaults);
        localStorage.setItem(`contacts_${currentUser.id}`, JSON.stringify(defaults));
      }
    }
  }, [currentUser]);

  const handleLogin = (name: string, id: string) => {
    const user: User = { 
      id, 
      name, 
      avatar: `https://picsum.photos/seed/${id}/200`,
      bio: "Hey there! I'm using Hafeez Chat."
    };
    setCurrentUser(user);
    localStorage.setItem('last_user', JSON.stringify(user));
  };

  const updateMyProfile = (updates: Partial<User>) => {
    if (!currentUser) return;
    const updatedUser = { ...currentUser, ...updates };
    setCurrentUser(updatedUser);
    localStorage.setItem('last_user', JSON.stringify(updatedUser));
  };

  const handleAddContact = (id: string, name: string) => {
    if (contacts.find(c => c.id === id)) return;
    const newContact: Contact = {
      id,
      name,
      avatar: `https://picsum.photos/seed/${id}/200`,
      bio: "I am a new user on Hafeez Chat.",
      status: 'offline',
      isAI: false
    };
    const updated = [...contacts, newContact];
    setContacts(updated);
    if (currentUser) {
      localStorage.setItem(`contacts_${currentUser.id}`, JSON.stringify(updated));
    }
    setSelectedContact(newContact);
  };

  const onRemoteTyping = (senderId: string, isTyping: boolean) => {
    setTypingMap(prev => ({ ...prev, [senderId]: isTyping }));
  };

  if (!currentUser) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#f0f2f5]">
      <div className="flex w-full h-full md:h-[95vh] md:w-[95vw] md:m-auto md:shadow-2xl overflow-hidden bg-white relative">
        
        {/* Profile Drawer */}
        <ProfileDrawer 
          isOpen={showMyProfile} 
          user={currentUser} 
          onClose={() => setShowMyProfile(false)} 
          onUpdate={updateMyProfile}
        />

        {/* Sidebar */}
        <div className={`${isSidebarOpen ? 'w-full md:w-[400px]' : 'hidden'} md:block border-r border-gray-300 flex-shrink-0 bg-white z-20`}>
          <Sidebar 
            contacts={contacts} 
            currentUser={currentUser} 
            selectedContact={selectedContact}
            typingMap={typingMap}
            onOpenProfile={() => setShowMyProfile(true)}
            onSelectContact={(contact) => {
              setSelectedContact(contact);
              if (window.innerWidth < 768) setIsSidebarOpen(false);
            }}
            onAddContact={handleAddContact}
          />
        </div>

        {/* Chat Window Container */}
        <div className={`${!isSidebarOpen || window.innerWidth >= 768 ? 'flex' : 'hidden'} flex-1 h-full bg-[#e5ddd5] relative`}>
          {selectedContact ? (
            <>
              <ChatWindow 
                key={selectedContact.id}
                contact={selectedContact} 
                currentUser={currentUser} 
                isRemoteTyping={!!typingMap[selectedContact.id]}
                onRemoteTyping={onRemoteTyping}
                onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
                onOpenContactInfo={() => setShowContactInfo(true)}
              />
              <ContactInfoDrawer 
                isOpen={showContactInfo} 
                contact={selectedContact} 
                onClose={() => setShowContactInfo(false)} 
              />
            </>
          ) : (
            <div className="hidden md:flex flex-col items-center justify-center w-full whatsapp-bg opacity-50">
              <i className="fa-brands fa-whatsapp text-8xl text-[#00a884] mb-4"></i>
              <h2 className="text-3xl text-gray-600 font-light">Hafeez Chat Web</h2>
              <p className="text-gray-500 mt-2">Send and receive real messages using User IDs</p>
              <div className="mt-8 p-4 bg-white/80 rounded-lg text-sm text-gray-600 border border-gray-200">
                <p><strong>Your ID:</strong> {currentUser.id}</p>
                <p>Share this ID to chat with others!</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default App;
