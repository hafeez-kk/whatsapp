
import { Message, BroadcastMessage, Contact } from '../types';

const CHANNEL_NAME = 'hafeez_chat_network';

export class ChatEngine {
  private channel: BroadcastChannel;
  private onMessageCallback: (msg: Message) => void;
  private onTypingCallback: (senderId: string, isTyping: boolean) => void;
  private currentUserId: string;

  constructor(
    userId: string, 
    onMessage: (msg: Message) => void,
    onTyping: (senderId: string, isTyping: boolean) => void
  ) {
    this.currentUserId = userId;
    this.onMessageCallback = onMessage;
    this.onTypingCallback = onTyping;
    this.channel = new BroadcastChannel(CHANNEL_NAME);
    
    this.channel.onmessage = (event) => {
      const data: BroadcastMessage = event.data;
      if (data.type === 'CHAT_MESSAGE') {
        const msg: Message = data.payload;
        if (msg.receiverId === this.currentUserId) {
          this.onMessageCallback(msg);
          this.sendStatusUpdate(msg.id, 'delivered', msg.senderId);
        }
      } else if (data.type === 'TYPING_STATUS') {
        const { senderId, receiverId, isTyping } = data.payload;
        if (receiverId === this.currentUserId) {
          this.onTypingCallback(senderId, isTyping);
        }
      }
    };
  }

  sendMessage(msg: Message) {
    this.saveMessage(msg);
    this.channel.postMessage({
      type: 'CHAT_MESSAGE',
      payload: msg
    });
  }

  sendTypingStatus(isTyping: boolean, targetId: string) {
    this.channel.postMessage({
      type: 'TYPING_STATUS',
      payload: {
        senderId: this.currentUserId,
        receiverId: targetId,
        isTyping
      }
    });
  }

  private sendStatusUpdate(messageId: string, status: string, targetId: string) {
    this.channel.postMessage({
      type: 'STATUS_UPDATE',
      payload: { messageId, status, targetId }
    });
  }

  private saveMessage(msg: Message) {
    const key = `chat_history_${this.currentUserId}`;
    const history = JSON.parse(localStorage.getItem(key) || '[]');
    history.push(msg);
    localStorage.setItem(key, JSON.stringify(history));
  }

  getHistory(otherId: string): Message[] {
    const key = `chat_history_${this.currentUserId}`;
    const history: Message[] = JSON.parse(localStorage.getItem(key) || '[]');
    return history.filter(m => m.senderId === otherId || m.receiverId === otherId);
  }

  close() {
    this.channel.close();
  }
}
