
import React, { useState } from 'react';

interface LoginProps {
  onLogin: (name: string, id: string) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [name, setName] = useState('');
  const [id, setId] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim() && id.trim()) {
      onLogin(name, id);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-[#00a884]">
      <div className="bg-white p-8 rounded-lg shadow-xl w-full max-w-md">
        <div className="flex flex-col items-center mb-8">
          <i className="fa-brands fa-whatsapp text-6xl text-[#00a884] mb-4"></i>
          <h1 className="text-2xl font-bold text-gray-700">Welcome to Hafeez Chat</h1>
          <p className="text-gray-500 text-sm">Sign in to start chatting</p>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Display Name</label>
            <input 
              type="text" 
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-[#00a884] focus:outline-none transition"
              placeholder="Enter your name"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">User ID</label>
            <input 
              type="text" 
              value={id}
              onChange={(e) => setId(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-[#00a884] focus:outline-none transition"
              placeholder="e.g. user_123"
              required
            />
          </div>
          <button 
            type="submit"
            className="w-full bg-[#00a884] hover:bg-[#008f72] text-white font-semibold py-2 px-4 rounded shadow transition-colors"
          >
            Start Chatting
          </button>
        </form>
        
        <div className="mt-8 pt-6 border-t border-gray-100 text-center text-xs text-gray-400">
          Powered by Google Gemini Models
        </div>
      </div>
    </div>
  );
};

export default Login;
