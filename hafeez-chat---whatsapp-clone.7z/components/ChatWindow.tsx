
import React, { useState, useEffect, useRef } from 'react';
import { Contact, User, Message } from '../types';
import { GoogleGenAI, GenerateContentResponse } from '@google/genai';
import MessageBubble from './MessageBubble';
import VoiceModal from './VoiceModal';
import { ChatEngine } from '../services/ChatEngine';

interface ChatWindowProps {
  contact: Contact;
  currentUser: User;
  isRemoteTyping: boolean;
  onRemoteTyping: (senderId: string, isTyping: boolean) => void;
  onToggleSidebar: () => void;
  onOpenContactInfo: () => void;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ contact, currentUser, isRemoteTyping, onRemoteTyping, onToggleSidebar, onOpenContactInfo }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isAITyping, setIsAITyping] = useState(false);
  const [isVoiceOpen, setIsVoiceOpen] = useState(false);
  const [streamingMessage, setStreamingMessage] = useState<string | null>(null);
  
  // Voice Note Recording States
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordingIntervalRef = useRef<number | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<ChatEngine | null>(null);
  const aiRef = useRef<any>(null);
  const typingTimeoutRef = useRef<number | null>(null);

  useEffect(() => {
    const engine = new ChatEngine(
      currentUser.id, 
      (incomingMsg) => {
        if (incomingMsg.senderId === contact.id) {
          setMessages(prev => [...prev, incomingMsg]);
        }
      },
      onRemoteTyping
    );
    engineRef.current = engine;
    setMessages(engine.getHistory(contact.id));

    const initAI = async () => {
      const genAI = new GoogleGenAI({ apiKey: process.env.API_KEY });
      aiRef.current = genAI.chats.create({
        model: 'gemini-3-flash-preview',
        config: {
          systemInstruction: `You are simulating a person named "${contact.name}" with ID "${contact.id}". 
          The user is "${currentUser.name}". Reply in a casual WhatsApp style. Use emojis occasionally.`
        }
      });
    };
    initAI();

    return () => {
      engine.close();
      if (recordingIntervalRef.current) clearInterval(recordingIntervalRef.current);
    };
  }, [contact, currentUser, onRemoteTyping]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isRemoteTyping, isAITyping, streamingMessage]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputText(e.target.value);
    
    if (engineRef.current) {
      engineRef.current.sendTypingStatus(true, contact.id);
      
      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
      typingTimeoutRef.current = window.setTimeout(() => {
        engineRef.current?.sendTypingStatus(false, contact.id);
      }, 2000);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      const chunks: Blob[] = [];

      mediaRecorder.ondataavailable = (e) => chunks.push(e.data);
      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(chunks, { type: 'audio/ogg; codecs=opus' });
        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = () => {
          const base64Audio = reader.result as string;
          sendAudioMessage(base64Audio);
        };
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingTime(0);
      recordingIntervalRef.current = window.setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    } catch (err) {
      console.error("Recording failed", err);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (recordingIntervalRef.current) clearInterval(recordingIntervalRef.current);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const sendAudioMessage = (audioUrl: string) => {
    const audioMessage: Message = {
      id: Date.now().toString(),
      audioUrl,
      senderId: currentUser.id,
      receiverId: contact.id,
      timestamp: Date.now(),
      status: 'sent'
    };
    setMessages(prev => [...prev, audioMessage]);
    engineRef.current?.sendMessage(audioMessage);
  };

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim()) return;

    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    engineRef.current?.sendTypingStatus(false, contact.id);

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText,
      senderId: currentUser.id,
      receiverId: contact.id,
      timestamp: Date.now(),
      status: 'sent'
    };

    setMessages(prev => [...prev, userMessage]);
    engineRef.current?.sendMessage(userMessage);
    setInputText('');

    if (contact.isAI || contact.id.includes('gemini')) {
      setIsAITyping(true);
      onRemoteTyping(contact.id, true); // Update sidebar
      
      try {
        let fullResponse = '';
        const stream = await aiRef.current.sendMessageStream({ message: userMessage.text });
        
        setIsAITyping(false); // Switch from bubble to streaming text
        setStreamingMessage('');

        for await (const chunk of stream) {
          const part = chunk as GenerateContentResponse;
          const text = part.text || '';
          fullResponse += text;
          setStreamingMessage(fullResponse);
        }

        const aiMessage: Message = {
          id: Date.now().toString(),
          text: fullResponse,
          senderId: contact.id,
          receiverId: currentUser.id,
          timestamp: Date.now(),
          status: 'read'
        };
        
        setMessages(prev => [...prev, aiMessage]);
        engineRef.current?.sendMessage(aiMessage);
        setStreamingMessage(null);
      } catch (err) {
        console.error(err);
        setIsAITyping(false);
      } finally {
        onRemoteTyping(contact.id, false); // Update sidebar
      }
    }
  };

  return (
    <div className="flex flex-col h-full w-full bg-white relative">
      <div className="flex items-center justify-between px-4 py-3 bg-[#f0f2f5] border-b border-gray-300 shadow-sm z-10">
        <div className="flex items-center cursor-pointer flex-1 min-w-0" onClick={onOpenContactInfo}>
          <button onClick={(e) => { e.stopPropagation(); onToggleSidebar(); }} className="mr-4 text-gray-500 md:hidden">
            <i className="fa-solid fa-arrow-left"></i>
          </button>
          <img src={contact.avatar} alt={contact.name} className="w-10 h-10 rounded-full mr-3 border border-gray-200" />
          <div className="flex flex-col min-w-0">
            <span className="text-gray-900 font-medium leading-tight truncate">{contact.name}</span>
            <span className="text-[11px] font-medium text-[#00a884]">
              {isRemoteTyping || isAITyping || streamingMessage !== null ? 'typing...' : 'online'}
            </span>
          </div>
        </div>
        <div className="flex items-center space-x-6 text-gray-500 text-lg">
          <button onClick={() => setIsVoiceOpen(true)} className="hover:text-[#00a884] transition"><i className="fa-solid fa-phone"></i></button>
          <button className="hover:text-gray-800 transition"><i className="fa-solid fa-video"></i></button>
          <button className="hover:text-gray-800 transition"><i className="fa-solid fa-ellipsis-vertical"></i></button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto whatsapp-bg p-4 md:px-20 space-y-2 pb-8">
        {messages.map((msg) => (
          <MessageBubble key={msg.id} message={msg} currentUserId={currentUser.id} />
        ))}
        
        {streamingMessage !== null && (
          <div className="flex justify-start">
             <div className="bg-white rounded-lg rounded-tl-none p-2 shadow-sm relative mb-0.5 max-w-[85%] md:max-w-[65%]">
                <p className="text-[14.5px] text-[#303030] pr-10 leading-relaxed whitespace-pre-wrap">{streamingMessage}</p>
                <div className="flex items-center justify-end mt-1 space-x-1">
                  <span className="text-[10px] text-gray-400 font-medium italic animate-pulse">Typing...</span>
                </div>
             </div>
          </div>
        )}

        {(isRemoteTyping || isAITyping) && streamingMessage === null && (
          <div className="flex justify-start">
             <div className="bg-white rounded-lg rounded-tl-none px-4 py-2 shadow-sm text-sm flex items-center space-x-1.5">
               <div className="flex space-x-1">
                 <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce"></div>
                 <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce delay-75"></div>
                 <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce delay-150"></div>
               </div>
               <span className="text-gray-400 text-xs font-medium pl-1 italic">typing...</span>
             </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="px-4 py-3 bg-[#f0f2f5] flex items-center space-x-3">
        {isRecording ? (
          <div className="flex-1 flex items-center justify-between px-4 py-2 bg-white rounded-lg animate-in slide-in-from-bottom duration-200">
            <div className="flex items-center space-x-3 text-red-500">
              <i className="fa-solid fa-microphone animate-pulse"></i>
              <span className="font-mono text-sm">{formatTime(recordingTime)}</span>
            </div>
            <div className="text-gray-400 text-xs italic">Recording...</div>
            <button onClick={stopRecording} className="text-[#00a884] font-bold text-sm uppercase">Send</button>
          </div>
        ) : (
          <>
            <button className="text-gray-500 text-xl hover:text-gray-800 transition"><i className="fa-regular fa-face-smile"></i></button>
            <button className="text-gray-500 text-xl hover:text-gray-800 transition"><i className="fa-solid fa-paperclip"></i></button>
            <form onSubmit={handleSendMessage} className="flex-1">
              <input 
                type="text" 
                placeholder="Type a message" 
                value={inputText} 
                onChange={handleInputChange}
                className="w-full bg-white border-none rounded-lg px-4 py-2 focus:outline-none text-sm shadow-sm" 
              />
            </form>
            {inputText.trim() ? (
              <button onClick={() => handleSendMessage()} className="bg-[#00a884] text-white rounded-full w-10 h-10 flex items-center justify-center hover:bg-[#008f72] shadow-sm transition-transform active:scale-90"><i className="fa-solid fa-paper-plane text-sm"></i></button>
            ) : (
              <button 
                onMouseDown={startRecording} 
                onMouseUp={stopRecording}
                onTouchStart={startRecording}
                onTouchEnd={stopRecording}
                className="bg-white text-gray-500 border border-gray-200 rounded-full w-10 h-10 flex items-center justify-center hover:text-[#00a884] hover:border-[#00a884] transition-all cursor-pointer"
              >
                <i className="fa-solid fa-microphone"></i>
              </button>
            )}
          </>
        )}
      </div>

      {isVoiceOpen && (
        <VoiceModal 
          onClose={() => setIsVoiceOpen(false)} 
          contactName={contact.name} 
          systemInstruction={`You are calling ${contact.name} (ID: ${contact.id}). Their preferred voice profile is ${contact.voice || 'Kore'}.`}
        />
      )}
    </div>
  );
};

export default ChatWindow;
