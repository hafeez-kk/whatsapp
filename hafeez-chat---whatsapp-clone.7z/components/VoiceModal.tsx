
import React, { useEffect, useState, useRef } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, Blob } from '@google/genai';

interface VoiceModalProps {
  onClose: () => void;
  contactName: string;
  systemInstruction: string;
  preferredVoice?: string;
}

const VoiceModal: React.FC<VoiceModalProps> = ({ onClose, contactName, systemInstruction, preferredVoice }) => {
  const [isActive, setIsActive] = useState(false);
  const [transcription, setTranscription] = useState('');
  const [modelTranscription, setModelTranscription] = useState('');
  const [error, setError] = useState<string | null>(null);
  
  const audioContextsRef = useRef<{ input: AudioContext; output: AudioContext } | null>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const sessionRef = useRef<any>(null);

  function decode(base64: string) {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  }

  async function decodeAudioData(
    data: Uint8Array,
    ctx: AudioContext,
    sampleRate: number,
    numChannels: number,
  ): Promise<AudioBuffer> {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  }

  function encode(bytes: Uint8Array) {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  function createBlob(data: Float32Array): Blob {
    const l = data.length;
    const int16 = new Int16Array(l);
    for (let i = 0; i < l; i++) {
      int16[i] = data[i] * 32768;
    }
    return {
      data: encode(new Uint8Array(int16.buffer)),
      mimeType: 'audio/pcm;rate=16000',
    };
  }

  const startSession = async () => {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextsRef.current = { input: inputCtx, output: outputCtx };

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setIsActive(true);
            const source = inputCtx.createMediaStreamSource(stream);
            const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              sessionPromise.then(s => s.sendRealtimeInput({ media: createBlob(inputData) }));
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputCtx.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            if (message.serverContent?.inputTranscription) setTranscription(prev => prev + ' ' + message.serverContent?.inputTranscription?.text);
            if (message.serverContent?.outputTranscription) setModelTranscription(prev => prev + ' ' + message.serverContent?.outputTranscription?.text);
            if (message.serverContent?.turnComplete) { setTranscription(''); setModelTranscription(''); }

            const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioData && audioContextsRef.current?.output) {
              const ctx = audioContextsRef.current.output;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              const audioBuffer = await decodeAudioData(decode(audioData), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(ctx.destination);
              source.addEventListener('ended', () => sourcesRef.current.delete(source));
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              sourcesRef.current.add(source);
            }
            if (message.serverContent?.interrupted) { sourcesRef.current.forEach(s => s.stop()); sourcesRef.current.clear(); nextStartTimeRef.current = 0; }
          },
          onerror: (e) => { setError("Connection error occurred."); },
          onclose: () => setIsActive(false)
        },
        config: {
          responseModalities: [Modality.AUDIO],
          systemInstruction: systemInstruction,
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: preferredVoice || 'Kore' } }
          },
          inputAudioTranscription: {},
          outputAudioTranscription: {}
        }
      });
      sessionRef.current = await sessionPromise;
    } catch (err: any) {
      setError(err.message || "Could not start voice session.");
    }
  };

  useEffect(() => {
    startSession();
    return () => {
      if (sessionRef.current) sessionRef.current.close();
      if (audioContextsRef.current) { audioContextsRef.current.input.close(); audioContextsRef.current.output.close(); }
    };
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm transition-opacity">
      <div className="bg-white rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl flex flex-col items-center p-8 animate-in fade-in zoom-in duration-300">
        <div className="flex justify-between w-full mb-8">
          <h2 className="text-xl font-bold text-gray-800">Voice Call</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition"><i className="fa-solid fa-xmark text-xl"></i></button>
        </div>

        <div className="relative mb-10">
          <div className={`w-32 h-32 rounded-full border-4 border-[#00a884] overflow-hidden ${isActive ? 'animate-pulse shadow-lg' : ''}`}>
            <img src={`https://picsum.photos/seed/${contactName}/200`} alt={contactName} className="w-full h-full object-cover" />
          </div>
          {isActive && <div className="absolute -bottom-2 -right-2 bg-green-500 w-8 h-8 rounded-full border-4 border-white flex items-center justify-center"><div className="w-2 h-2 bg-white rounded-full animate-ping"></div></div>}
        </div>

        <div className="text-center mb-8">
          <h3 className="text-2xl font-bold text-gray-800">{contactName}</h3>
          <p className="text-gray-500 mt-1">{isActive ? 'Connected' : 'Connecting...'}</p>
        </div>

        <div className="flex-1 w-full max-h-40 overflow-y-auto mb-8 space-y-4 px-4 bg-gray-50 p-2 rounded-lg border border-dashed border-gray-200">
           {transcription && <div className="text-gray-600 text-sm italic text-left"><span className="font-bold text-[10px] uppercase block text-gray-400">You:</span>{transcription}</div>}
           {modelTranscription && <div className="text-[#00a884] text-sm text-left"><span className="font-bold text-[10px] uppercase block text-gray-400">{contactName}:</span>{modelTranscription}</div>}
           {error && <div className="text-red-500 text-sm font-medium p-2 bg-red-50 rounded">{error}</div>}
           {!transcription && !modelTranscription && !error && <div className="text-center text-gray-400 text-xs py-4">Waiting for audio...</div>}
        </div>

        <div className="flex space-x-8">
          <button className="w-16 h-16 rounded-full bg-gray-100 text-gray-600 flex items-center justify-center hover:bg-gray-200 transition"><i className="fa-solid fa-microphone-slash"></i></button>
          <button onClick={onClose} className="w-16 h-16 rounded-full bg-red-500 text-white flex items-center justify-center hover:bg-red-600 shadow-lg shadow-red-200 transition active:scale-95"><i className="fa-solid fa-phone-slash text-2xl"></i></button>
          <button className="w-16 h-16 rounded-full bg-gray-100 text-gray-600 flex items-center justify-center hover:bg-gray-200 transition"><i className="fa-solid fa-volume-high"></i></button>
        </div>
      </div>
    </div>
  );
};

export default VoiceModal;
