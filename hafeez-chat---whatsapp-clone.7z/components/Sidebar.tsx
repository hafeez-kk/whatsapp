
import React, { useState } from 'react';
import { User, Contact } from '../types';

interface SidebarProps {
  contacts: Contact[];
  currentUser: User;
  selectedContact: Contact | null;
  typingMap: Record<string, boolean>;
  onOpenProfile: () => void;
  onSelectContact: (contact: Contact) => void;
  onAddContact: (id: string, name: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ contacts, currentUser, selectedContact, typingMap, onOpenProfile, onSelectContact, onAddContact }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [newId, setNewId] = useState('');
  const [newName, setNewName] = useState('');

  const filteredContacts = contacts.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    c.id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (newId.trim() && newName.trim()) {
      onAddContact(newId.trim(), newName.trim());
      setNewId('');
      setNewName('');
      setIsAdding(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-white relative">
      {/* Sidebar Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-[#f0f2f5] border-b border-gray-300">
        <div className="flex items-center">
          <img 
            src={currentUser.avatar} 
            alt="Me" 
            className="w-10 h-10 rounded-full cursor-pointer hover:opacity-80 transition" 
            onClick={onOpenProfile}
          />
          <div className="ml-3 hidden md:block overflow-hidden max-w-[150px]">
            <p className="font-semibold text-gray-700 text-sm truncate">{currentUser.name}</p>
            <p className="text-[10px] text-gray-500 font-mono truncate">ID: {currentUser.id}</p>
          </div>
        </div>
        <div className="flex items-center space-x-4 text-gray-500 text-lg">
          <button onClick={() => setIsAdding(!isAdding)} title="Add Contact" className="hover:text-[#00a884] transition"><i className="fa-solid fa-plus-circle"></i></button>
          <button className="hover:text-gray-800 transition"><i className="fa-solid fa-message"></i></button>
          <button className="hover:text-gray-800 transition"><i className="fa-solid fa-ellipsis-vertical"></i></button>
        </div>
      </div>

      {isAdding && (
        <div className="p-4 bg-[#f0f2f5] border-b border-gray-300 animate-in slide-in-from-top duration-200 shadow-inner">
          <form onSubmit={handleAdd} className="space-y-2">
            <input autoFocus className="w-full px-3 py-1.5 text-sm rounded border-none focus:ring-2 focus:ring-[#00a884] shadow-sm" placeholder="Enter User ID" value={newId} onChange={e => setNewId(e.target.value)} />
            <input className="w-full px-3 py-1.5 text-sm rounded border-none focus:ring-2 focus:ring-[#00a884] shadow-sm" placeholder="Display Name" value={newName} onChange={e => setNewName(e.target.value)} />
            <div className="flex space-x-2">
              <button type="submit" className="flex-1 bg-[#00a884] text-white text-xs py-1.5 rounded font-bold shadow hover:bg-[#008f72]">ADD</button>
              <button type="button" onClick={() => setIsAdding(false)} className="flex-1 bg-gray-300 text-gray-700 text-xs py-1.5 rounded font-bold">CANCEL</button>
            </div>
          </form>
        </div>
      )}

      <div className="p-2 bg-white border-b border-gray-100">
        <div className="relative">
          <span className="absolute inset-y-0 left-0 flex items-center pl-4 text-gray-400">
            <i className="fa-solid fa-magnifying-glass text-sm"></i>
          </span>
          <input type="text" placeholder="Search contacts or IDs" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="w-full pl-12 pr-4 py-1.5 bg-[#f0f2f5] border-none rounded-lg focus:outline-none text-sm placeholder:text-gray-500" />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        {filteredContacts.map((contact) => (
          <div key={contact.id} onClick={() => onSelectContact(contact)} className={`flex items-center px-4 py-3 cursor-pointer border-b border-gray-100 hover:bg-[#f5f6f6] transition-colors ${selectedContact?.id === contact.id ? 'bg-[#ebebeb]' : ''}`}>
            <div className="relative">
              <img src={contact.avatar} alt={contact.name} className="w-12 h-12 rounded-full mr-4 border border-gray-200 shadow-sm" />
              {contact.status === 'online' && <span className="absolute bottom-0 right-4 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></span>}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex justify-between items-baseline">
                <h3 className="text-gray-900 font-medium truncate">{contact.name}</h3>
                <span className="text-[10px] text-gray-500 uppercase">ID: {contact.id}</span>
              </div>
              <div className="flex justify-between items-center mt-1">
                {typingMap[contact.id] ? (
                  <p className="text-sm text-[#00a884] font-medium animate-pulse">typing...</p>
                ) : (
                  <p className="text-sm text-gray-500 truncate">{contact.lastMessage || 'Click to chat'}</p>
                )}
              </div>
            </div>
          </div>
        ))}
        {filteredContacts.length === 0 && (
          <div className="flex flex-col items-center justify-center p-10 text-gray-400 text-sm">
            <i className="fa-solid fa-user-plus text-3xl mb-2"></i>
            <p>No contacts found</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Sidebar;
