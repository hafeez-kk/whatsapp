
import React, { useState } from 'react';
import { User } from '../types';

interface ProfileDrawerProps {
  isOpen: boolean;
  user: User;
  onClose: () => void;
  onUpdate: (updates: Partial<User>) => void;
}

const PREBUILT_VOICES = ['Kore', 'Puck', 'Charon', 'Fenrir', 'Zephyr'];

const ProfileDrawer: React.FC<ProfileDrawerProps> = ({ isOpen, user, onClose, onUpdate }) => {
  const [editingName, setEditingName] = useState(false);
  const [editingBio, setEditingBio] = useState(false);
  const [tempName, setTempName] = useState(user.name);
  const [tempBio, setTempBio] = useState(user.bio || "");

  const handleSaveName = () => {
    onUpdate({ name: tempName });
    setEditingName(false);
  };

  const handleSaveBio = () => {
    onUpdate({ bio: tempBio });
    setEditingBio(false);
  };

  return (
    <div className={`absolute inset-y-0 left-0 w-full md:w-[400px] bg-[#f0f2f5] z-50 transition-transform duration-300 ease-in-out transform ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
      <div className="bg-[#008069] h-[108px] flex items-end px-6 pb-4">
        <div className="flex items-center text-white">
          <button onClick={onClose} className="mr-8">
            <i className="fa-solid fa-arrow-left text-xl"></i>
          </button>
          <h2 className="text-lg font-medium">Profile</h2>
        </div>
      </div>

      <div className="overflow-y-auto h-[calc(100%-108px)] pb-10">
        <div className="py-7 flex justify-center bg-[#f0f2f5]">
          <div className="relative group cursor-pointer">
            <img src={user.avatar} alt="Profile" className="w-48 h-48 rounded-full shadow-lg object-cover" />
            <div 
              className="absolute inset-0 bg-black/30 rounded-full opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center text-white transition-opacity"
              onClick={() => onUpdate({ avatar: `https://picsum.photos/seed/${Math.random()}/200` })}
            >
              <i className="fa-solid fa-camera text-2xl mb-1"></i>
              <span className="text-[10px] uppercase font-bold">Change Image</span>
            </div>
          </div>
        </div>

        <div className="bg-white px-8 py-4 shadow-sm mb-3">
          <label className="text-[#008069] text-xs font-medium mb-4 block uppercase tracking-wider">Your name</label>
          <div className="flex items-center justify-between">
            {editingName ? (
              <input 
                autoFocus
                type="text"
                className="w-full border-b-2 border-[#008069] outline-none py-1 text-gray-800"
                value={tempName}
                onChange={(e) => setTempName(e.target.value)}
                onBlur={handleSaveName}
                onKeyDown={(e) => e.key === 'Enter' && handleSaveName()}
              />
            ) : (
              <>
                <span className="text-gray-800 text-[17px]">{user.name}</span>
                <button onClick={() => setEditingName(true)} className="text-gray-400 hover:text-gray-600">
                  <i className="fa-solid fa-pencil text-sm"></i>
                </button>
              </>
            )}
          </div>
        </div>

        <div className="bg-white px-8 py-4 shadow-sm mb-3">
          <label className="text-[#008069] text-xs font-medium mb-4 block uppercase tracking-wider">About</label>
          <div className="flex items-center justify-between">
            {editingBio ? (
              <input 
                autoFocus
                type="text"
                className="w-full border-b-2 border-[#008069] outline-none py-1 text-gray-800"
                value={tempBio}
                onChange={(e) => setTempBio(e.target.value)}
                onBlur={handleSaveBio}
                onKeyDown={(e) => e.key === 'Enter' && handleSaveBio()}
              />
            ) : (
              <>
                <span className="text-gray-800 text-[17px]">{user.bio || "Hey there! I'm using Hafeez Chat."}</span>
                <button onClick={() => setEditingBio(true)} className="text-gray-400 hover:text-gray-600">
                  <i className="fa-solid fa-pencil text-sm"></i>
                </button>
              </>
            )}
          </div>
        </div>

        {/* Voice Preference Section */}
        <div className="bg-white px-8 py-4 shadow-sm mb-3">
          <label className="text-[#008069] text-xs font-medium mb-4 block uppercase tracking-wider">Personal AI Voice</label>
          <div className="flex flex-wrap gap-2 mt-2">
            {PREBUILT_VOICES.map(voice => (
              <button
                key={voice}
                onClick={() => onUpdate({ voice })}
                className={`px-3 py-1.5 rounded-full text-xs font-bold border transition-all ${
                  (user.voice || 'Kore') === voice 
                  ? 'bg-[#008069] text-white border-[#008069]' 
                  : 'bg-white text-gray-500 border-gray-200 hover:border-[#008069]'
                }`}
              >
                {voice}
              </button>
            ))}
          </div>
          <p className="text-gray-400 text-[11px] mt-3">Select a voice for your AI calls and voice messages.</p>
        </div>

        <div className="bg-white px-8 py-4 shadow-sm">
          <label className="text-[#008069] text-xs font-medium mb-4 block uppercase tracking-wider">User ID</label>
          <span className="text-gray-800 text-[17px] font-mono">{user.id}</span>
        </div>
      </div>
    </div>
  );
};

export default ProfileDrawer;
