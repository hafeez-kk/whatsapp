
import React from 'react';
import { Message } from '../types';

interface MessageBubbleProps {
  message: Message;
  currentUserId: string;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message, currentUserId }) => {
  const isUser = message.senderId === currentUserId;
  
  return (
    <div className={`flex w-full ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div 
        className={`max-w-[85%] md:max-w-[65%] p-2 rounded-lg shadow-sm relative mb-0.5 ${
          isUser 
            ? 'bg-[#dcf8c6] rounded-tr-none' 
            : 'bg-white rounded-tl-none'
        }`}
      >
        {message.audioUrl ? (
          <div className="flex items-center space-x-3 py-1 px-1">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isUser ? 'bg-[#73c596]' : 'bg-[#00a884]'} text-white`}>
              <i className="fa-solid fa-play ml-1"></i>
            </div>
            <div className="flex-1">
              <div className="h-1.5 w-full bg-gray-200 rounded-full relative overflow-hidden">
                <div className="absolute inset-y-0 left-0 bg-gray-400 w-1/3"></div>
              </div>
              <audio src={message.audioUrl} className="hidden" />
              <div className="flex justify-between items-center mt-1">
                <span className="text-[10px] text-gray-500">Voice message</span>
                <span className="text-[10px] text-gray-400">0:04</span>
              </div>
            </div>
          </div>
        ) : (
          <p className="text-[14.5px] text-[#303030] pr-10 leading-relaxed whitespace-pre-wrap">{message.text}</p>
        )}
        
        <div className="flex items-center justify-end mt-1 space-x-1">
          <span className="text-[10px] text-gray-400 font-medium">
            {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })}
          </span>
          {isUser && (
            <span className="text-[12px] flex items-center">
              <i className={`fa-solid fa-check-double ${message.status === 'read' ? 'text-blue-400' : 'text-gray-400'}`}></i>
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

export default MessageBubble;
