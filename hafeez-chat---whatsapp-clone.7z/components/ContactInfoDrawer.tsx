
import React from 'react';
import { Contact } from '../types';

interface ContactInfoDrawerProps {
  isOpen: boolean;
  contact: Contact;
  onClose: () => void;
}

const ContactInfoDrawer: React.FC<ContactInfoDrawerProps> = ({ isOpen, contact, onClose }) => {
  return (
    <div className={`absolute inset-y-0 right-0 w-full md:w-[400px] bg-[#f0f2f5] z-50 transition-transform duration-300 ease-in-out transform border-l border-gray-200 ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
      {/* Header */}
      <div className="bg-[#f0f2f5] h-[60px] flex items-center px-4 border-b border-gray-300">
        <button onClick={onClose} className="mr-6 text-gray-500">
          <i className="fa-solid fa-xmark text-xl"></i>
        </button>
        <h2 className="text-gray-800 font-medium">Contact info</h2>
      </div>

      <div className="overflow-y-auto h-[calc(100%-60px)]">
        {/* Avatar Section */}
        <div className="py-7 flex flex-col items-center bg-white shadow-sm mb-3">
          <img 
            src={contact.avatar} 
            alt={contact.name} 
            className="w-48 h-48 rounded-full mb-4 shadow-md"
          />
          <h3 className="text-xl text-gray-900 font-medium">{contact.name}</h3>
          <p className="text-gray-500 text-sm">{contact.id}</p>
        </div>

        {/* About Section */}
        <div className="bg-white px-8 py-4 shadow-sm mb-3">
          <label className="text-gray-500 text-xs mb-2 block">About</label>
          <p className="text-gray-800 text-[16px]">{contact.bio || "No status set."}</p>
        </div>

        {/* Multimedia Section (Placeholder) */}
        <div className="bg-white px-8 py-4 shadow-sm mb-3">
          <div className="flex justify-between items-center mb-4">
            <label className="text-gray-500 text-xs">Media, links and docs</label>
            <i className="fa-solid fa-chevron-right text-xs text-gray-400"></i>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {[1, 2, 3].map(i => (
              <div key={i} className="aspect-square bg-gray-100 rounded flex items-center justify-center">
                <i className="fa-regular fa-image text-gray-300 text-xl"></i>
              </div>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div className="bg-white shadow-sm mb-3">
          <button className="w-full text-left px-8 py-4 text-red-500 hover:bg-gray-50 flex items-center">
            <i className="fa-solid fa-ban mr-6"></i>
            <span>Block {contact.name}</span>
          </button>
          <button className="w-full text-left px-8 py-4 text-red-500 hover:bg-gray-50 flex items-center border-t border-gray-100">
            <i className="fa-solid fa-thumbs-down mr-6"></i>
            <span>Report {contact.name}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default ContactInfoDrawer;
