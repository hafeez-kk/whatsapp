
export interface Message {
  id: string;
  text?: string;
  audioUrl?: string; // base64 data for voice notes
  senderId: string;
  receiverId: string;
  timestamp: number;
  status: 'sent' | 'delivered' | 'read';
}

export interface Contact {
  id: string;
  name: string;
  avatar: string;
  bio?: string;
  voice?: string; // Preferred Gemini voice
  lastMessage?: string;
  status: 'online' | 'offline';
  isAI: boolean;
}

export interface User {
  id: string;
  name: string;
  avatar: string;
  bio?: string;
  voice?: string; // User's AI persona voice
}

export interface BroadcastMessage {
  type: 'CHAT_MESSAGE' | 'STATUS_UPDATE' | 'HANDSHAKE' | 'TYPING_STATUS';
  payload: any;
}
